from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import html, re, json

OUT=Path('outputs/Telegram - тест 03');OUT.mkdir(parents=True,exist_ok=True)
TITLE='🚀 1 000 ПОДПИСЧИКОВ — И РОЗЫГРЫШ!'
INTRO='До первой тысячи в EXITDLC осталось совсем немного!'
BODY='Как только на канале будет 1 000 подписчиков, запустим розыгрыш для нашего сообщества Standoff 2.'
PRIZE='🎁 Призовой фонд — 500 ⭐️\n20 победителей — по 25 ⭐️ каждому.'
CTA='Как приблизить розыгрыш?'
ITEMS=['• Подпишитесь на EXITDLC, если ещё не с нами.',
       '• Поделитесь этим постом с друзьями или в чате клана.',
       '• Поддержите анонс реакцией 🔥.']
END='Спасибо за поддержку! Вместе доберём первую тысячу 🤝'
plain='\n\n'.join([TITLE,INTRO,BODY,PRIZE,CTA+'\n'+'\n'.join(ITEMS),END])
(OUT/'Пост без форматирования.txt').write_text(plain,encoding='utf-8-sig')

F=Path('C:/Windows/Fonts')
def font(kind,size):
    return ImageFont.truetype(str(F/{'normal':'segoeui.ttf','bold':'seguisb.ttf','italic':'segoeuii.ttf','emoji':'seguiemj.ttf'}[kind]),size)

def render(width,filename):
    scale=width/840
    sf=lambda v:round(v*scale)
    font_size=sf(32);line=sf(44)
    fonts={kind:font(kind,font_size) for kind in ['normal','bold','italic','emoji']}
    canvas=Image.new('RGB',(width,sf(2400)),'#0e1720');draw=ImageDraw.Draw(canvas)
    def emoji_char(ch):
        return ord(ch)>=0x1f000 or ch in '⭐▫️🚀🎁🔥🤝'
    def segments(text,kind):
        result=[]
        for ch in text.replace('\ufe0f', ''):
            k='emoji' if emoji_char(ch) else kind
            if result and result[-1][1]==k:result[-1]=(result[-1][0]+ch,k)
            else:result.append((ch,k))
        return result
    def measure(text,kind):
        return sum(draw.textlength(t,font=fonts[k]) for t,k in segments(text,kind))
    def write(text,x,y,kind='normal',fill='#f0f2f4'):
        for t,k in segments(text,kind):
            draw.text((x,y),t,font=fonts[k],fill=fill,embedded_color=(k=='emoji'),stroke_width=0)
            x+=draw.textlength(t,font=fonts[k])
    def paragraph(text,x,y,maxwidth,kind='normal'):
        for raw_line in text.split('\n'):
            current=''
            for word in raw_line.split(' '):
                test=current+' '+word if current else word
                if current and measure(test,kind)>maxwidth:
                    write(current,x,y,kind);y+=line;current=word
                else:current=test
            write(current,x,y,kind);y+=line
        return y
    # Phone UI is a labeled synthetic mockup, not a real published post.
    draw.rectangle((0,0,width,sf(196)),fill='#182530')
    draw.text((sf(28),sf(15)),'21:57',font=font('bold',sf(25)),fill='white')
    draw.line([(width-sf(135),sf(35)),(width-sf(125),sf(25)),(width-sf(115),sf(35))],fill='white',width=sf(3))
    draw.rounded_rectangle((width-sf(91),sf(24),width-sf(34),sf(47)),radius=sf(5),outline='white',width=sf(2))
    draw.rectangle((width-sf(87),sf(28),width-sf(45),sf(43)),fill='white')
    draw.line([(sf(51),sf(102)),(sf(30),sf(122)),(sf(51),sf(142))],fill='#f6f8fa',width=sf(4))
    draw.ellipse((sf(81),sf(83),sf(155),sf(157)),fill='#314154')
    draw.text((sf(101),sf(96)),'E',font=font('bold',sf(36)),fill='#d48aff')
    draw.text((sf(174),sf(91)),'Exit - DLC for Standoff 2',font=font('bold',sf(30)),fill='#f2f5f7')
    draw.text((sf(174),sf(134)),'предпросмотр публикации',font=font('normal',sf(24)),fill='#8ea2b4')
    for yy in [108,123,138]:draw.ellipse((width-sf(40),sf(yy),width-sf(34),sf(yy+6)),fill='#b9c7d3')
    draw.rounded_rectangle((width//2-sf(124),sf(222),width//2+sf(124),sf(264)),radius=sf(21),fill='#253a4b')
    draw.text((width//2-sf(92),sf(226)),'Тестовый макет',font=font('normal',sf(24)),fill='#d3dfe9')
    x=sf(48); top=sf(294); y=top+sf(22); maxwidth=width-sf(114)
    # Lay out into a transparent layer first to fit the bubble to actual text.
    textlayer=Image.new('RGBA',canvas.size,(0,0,0,0));background=canvas;canvas=textlayer;draw=ImageDraw.Draw(textlayer)
    draw.text((x,y),'Exit - DLC for Standoff 2',font=font('bold',sf(27)),fill='#5cd8e9');y+=sf(43)
    y=paragraph(TITLE,x,y,maxwidth,'bold')+sf(27)
    y=paragraph(INTRO,x,y,maxwidth,'italic')+sf(27)
    y=paragraph(BODY,x,y,maxwidth)+sf(28)
    quote_top=y-sf(7);qx=x+sf(20)
    # Quote length may wrap naturally at this phone width.
    q_y=paragraph(PRIZE,qx,y,maxwidth-sf(35),'bold')
    quote_bottom=q_y+sf(8)
    quote=Image.new('RGBA',textlayer.size,(0,0,0,0));qd=ImageDraw.Draw(quote)
    qd.rounded_rectangle((x,quote_top,width-sf(50),quote_bottom),radius=sf(8),fill='#203d49')
    qd.rounded_rectangle((x,quote_top,x+sf(6),quote_bottom),radius=sf(3),fill='#64c9d9')
    textlayer=Image.alpha_composite(quote,textlayer);draw=ImageDraw.Draw(textlayer)
    y=quote_bottom+sf(30)
    y=paragraph(CTA,x,y,maxwidth,'bold')+sf(8)
    for item in ITEMS:y=paragraph(item,x,y,maxwidth)+sf(8)
    y+=sf(20);y=paragraph(END,x,y,maxwidth,'italic')
    y+=sf(16)
    draw.text((width-sf(225),y),'предпросмотр',font=font('normal',sf(21)),fill='#8097aa')
    bubble_bottom=y+sf(47)
    output_height=max(sf(1680),bubble_bottom+sf(180))
    bd=ImageDraw.Draw(background)
    bd.rounded_rectangle((sf(22),top,width-sf(26),bubble_bottom),radius=sf(27),fill='#192936')
    background=Image.alpha_composite(background.convert('RGBA'),textlayer).convert('RGB')
    background=background.crop((0,0,width,output_height));bd=ImageDraw.Draw(background)
    bottom=output_height-sf(120)
    bd.rectangle((0,bottom,width,output_height),fill='#182530')
    bd.rounded_rectangle((sf(24),bottom+sf(15),width-sf(24),bottom+sf(80)),radius=sf(32),fill='#22333f')
    bd.text((sf(51),bottom+sf(26)),'Публикация…',font=font('normal',sf(28)),fill='#8299ac')
    bd.rounded_rectangle((width//2-sf(90),output_height-sf(20),width//2+sf(90),output_height-sf(12)),radius=sf(4),fill='#d2d8de')
    background.save(OUT/filename)
    return {'width':width,'height':output_height,'image':filename}

render(840,'Предпросмотр.png')
print('Created plain TXT and quote-restored preview.')
